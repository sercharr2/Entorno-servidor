<?php

if(isset($_POST["input"])){

    $usuarioV = false;
$contraseniaV = false;
$contraseniaEx = '';
$usuarioEx = '';
echo $_POST["contraseniaR"].'  '.$_POST["verificaContrasenia"].'   '.$_POST["usuarioR"].'   '.isset($_POST["emailR"]).'   '.isset($_POST["websiteR"]).'   '.isset($_POST["commentR"]).'  '.isset($_POST["genderR"]);

if(isset($_POST["usuarioR"] && isset($_POST["contraseniaR"] && isset($_POST["verificaContrasenia"] &&isset($_POST["emailR"] && isset($_POST["genderR"]){

    if($_POST["contraseniaR"] == $_POST["verificaContrasenia"]){

    $contraseniaV = true;

    }

    $conn = new mysqli('localhost', 'root', '', 'bdsimon');
    if ($conn->connect_error)
        die("Fatal Error");


    $query = "SELECT Nombre FROM usuarios";
    $result = $conn->query($query);
    if (!$result)
        die("Fatal Error");

    if ($result->num_rows > 0) {
        // usar while para iterar cada fila y evitar avanzar el puntero varias veces
        while ($row = $result->fetch_assoc()) {

            $nombre1 = $row['Nombre'];

            if ($nombre1 == $_POST['usuarioR']) {

                $usuarioV = true;

            }else{

                $usuarioV = false;

            }

        }
    }
    if($usuarioV == false){

       $usuarioEx = "<p style='color: red'>*usuario no existente, intente con otro</p>";

    }
    if($contraseniaV == false){

        $contraseniaEx = "<p style='color: red'>*Eror al introducir la contraseña</p>";

    }
    if($contraseniaV && $usuarioV){

        $nombre = $_POST["usuarioR"];
    $clave = $_POST["contraseniaR"];

    $query = "INSERT INTO `usuarios` (`Nombre`, `Clave`,`Rol`) VALUES ('$nombre','$clave',0)";
    $result = $conn->query($query);
    if (!$result)
        die("Fatal Error");

    echo<<<_END

        <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro Simon</title>
</head>
<body>
    <h1>Simón</h1>
        <h2> Registro de sesión:</h2>
        <p>Registro completado</p>
        <p>Pulse el boton para volver al inicio de sesión</p>
    <br>
    <form method="get" action="simon.final.php" style="margin-top:16px;">
    <button type="submit">volver al inicio</button>
    </form>

_END;

    }else{

         echo <<<_END
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro Simon</title>
</head>
<body>
    <h1>PHP form Validation Example</h1>
    <br>
    <form method="post" action="formulario.php">
_END;

       echo "<lavel>Usuario:</lavel>";
        echo'<input type="text" name="usuarioR">' .$usuarioEx ;

        echo'<lavel>E-mail:</lavel>';
        echo'<input type="email" name="emailR"><br><br>';

        echo'<lavel>Website:</lavel>';
        echo'<input type="text" name="websiteR"><br><br>';

        echo'<lavel>Comment:</lavel>';
        echo "<textarea name='commentR'></textarea> <br><br>";

        echo'<lavel>Gender:</lavel>';
        echo"<input type='radio' name='genderR' value='m'>";
        echo"<label>Male</label><br>";
        echo"<input type='radio' name='genderR' value='f'>";
        echo"<label>Female</label><br><br>";
        
        
        echo'<lavel>Contraseña:</lavel>';
        echo'<input type="password" name="contraseniaR"><br><br>';
        

        echo'<lavel>Repite la contraseña:</lavel>';
        echo'<input type="password" name="verificaContrasenia">';
        echo $contraseniaEx;
        echo'<br>';


echo <<<_END

        <input type="submit" name="input" value = "Registrarse">

    </form>

_END;


    }
    }elseif()
}    
else{

     echo <<<_END
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro Simon</title>
</head>
<body>
    <h1>Simón</h1>
        <h2> Registro de sesión:</h2>
        <p>llena los campos usuario y contraseña con las nuevas credenciales</p>
    <br>
    <form method="post" action="formulario.php">

       <lavel>Usuario:</lavel>
        <input type="text" name="usuarioR"><br><br>

        <lavel>E-mail:</lavel>
        <input type="email" name="emailR"><br><br>

        <lavel>Website:</lavel>
        <input type="text" name="websiteR"><br><br>

        <lavel>Comment:</lavel>
        <textarea name='commentR'></textarea><br><br>

        <lavel>Gender:</lavel>
        <input type='radio' name='genderR' value='m'>
        <label>Male</label>
        <input type='radio' name='genderR' value='f'>
        <label>Female</label><br><br>
        
        
        <lavel>Contraseña:</lavel>
        <input type="password" name="contraseniaR"><br><br>
        

        <lavel>Repite la contraseña:</lavel>
        <input type="password" name="verificaContrasenia">
        <br><br>

        <input type="submit" name="input" value = "Registrarse">

    </form>

_END;

}
?>